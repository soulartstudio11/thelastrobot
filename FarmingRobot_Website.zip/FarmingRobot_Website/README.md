# Farming Robot — Cross-platform Website + Bluetooth Bridge

This project keeps your Arduino Uno and existing BLE Bluetooth module. The website works in modern phone and desktop browsers. A nearby computer runs the bridge that connects to the robot over Bluetooth and stays connected to the hosted backend.

## Architecture

Phone / computer browser → Node.js backend (Render or another host) → WebSocket bridge on the nearby computer → BLE Bluetooth module → Arduino Uno.

**Important:** The nearby bridge computer must remain powered on, connected to the internet, and within Bluetooth range of the robot for remote commands to work. The Arduino and robot power must also remain on. Hosting the backend alone cannot create a Bluetooth connection to the robot.

## Project structure

- `server/` — Node.js API, WebSocket relay, and website files.
- `bridge/` — Python BLE bridge for the nearby computer.
- `render.yaml` — optional Render Blueprint configuration.

## 1. Deploy the backend

1. Push the contents of this project to a GitHub repository.
2. In Render, create a **Web Service** from that repository.
3. Set **Root Directory** to `server`.
4. Build command: `npm install`
5. Start command: `npm start`
6. Add these environment variables in Render:
   - `BRIDGE_TOKEN` = a long random secret used only by the bridge.
   - `WEB_CONTROL_KEY` = a separate long secret you will enter in the website.
   - `NODE_ENV` = `production`
7. Deploy and copy the service URL, e.g. `https://your-service.onrender.com`.

Do not put either secret in GitHub or in the website source code. The backend uses JSON files for basic runtime status only; it does not require a database. On some hosts, local files can be ephemeral, so do not treat local JSON files as permanent cloud storage.

## 2. Install the bridge on the nearby computer

The bridge computer can be Windows or Ubuntu/Linux. Python 3.10+ is recommended. Bluetooth must be enabled and the OS must be able to see the module.

### Windows (PowerShell)

```powershell
cd bridge
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:BACKEND_URL="wss://YOUR-SERVICE.onrender.com/ws"
$env:BRIDGE_TOKEN="YOUR_BRIDGE_TOKEN"
$env:BLE_DEVICE_NAME="FARMINGROBOT"
py bridge.py
```

If PowerShell blocks activation, use `.\.venv\Scripts\python.exe -m pip install -r requirements.txt` and then `.\.venv\Scripts\python.exe bridge.py`.

### Ubuntu/Linux

Install Bluetooth tools and Python support first:

```bash
sudo apt update
sudo apt install -y bluetooth bluez python3-venv
cd bridge
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
export BACKEND_URL="wss://YOUR-SERVICE.onrender.com/ws"
export BRIDGE_TOKEN="YOUR_BRIDGE_TOKEN"
export BLE_DEVICE_NAME="FARMINGROBOT"
python bridge.py
```

Replace `YOUR-SERVICE` and the token placeholders with your actual values. Keep this terminal open while controlling the robot. Later, you can configure the bridge to start automatically as a service.

## 3. Open the website

Open the Render service URL in your phone or computer browser. Tap **Access settings** and enter the `WEB_CONTROL_KEY` you configured in Render. The website must be served over HTTPS for reliable browser microphone access.

## Commands

The bridge sends one-character commands to BLE characteristic `0000ffe1-0000-1000-8000-00805f9b34fb`:

- Forward: `F`
- Backward: `B`
- Left: `L`
- Right: `R`
- Stop: `S`
- Water ON: `W`
- Water OFF: `w`
- Moisture check: `M`

**Check your Arduino sketch before driving:** these command letters must match the sketch exactly. The bridge does not automatically change your Arduino firmware. If your sketch uses a different stop command or expects newline-terminated text, update `COMMANDS` in `server/public/app.js` or the write logic in `bridge.py` accordingly.

## Safety notes

- Test with the wheels lifted and the pump disconnected first.
- Keep an accessible physical power switch.
- This is a starter project, not a safety-certified controller.
- Voice input depends on browser/device support and microphone permission.
- Soil moisture readings will only appear if your Arduino firmware sends a response/notification that the BLE module exposes. The exact notification format depends on your firmware and module. This starter reports connection status and command acknowledgements; it does not invent moisture readings.
- Do not share your control key or bridge token. Use a unique, long random value for each.
