import asyncio
import json
import os
import platform
from datetime import datetime, timezone

from bleak import BleakClient, BleakScanner
from websockets.asyncio.client import connect

BACKEND_URL = os.environ.get("BACKEND_URL", "").strip()
BRIDGE_TOKEN = os.environ.get("BRIDGE_TOKEN", "").strip()
BLE_DEVICE_NAME = os.environ.get("BLE_DEVICE_NAME", "FARMINGROBOT").strip()
BLE_ADDRESS = os.environ.get("BLE_ADDRESS", "").strip()
CHAR_UUID = os.environ.get(
    "BLE_CHARACTERISTIC_UUID",
    "0000ffe1-0000-1000-8000-00805f9b34fb"
).strip()
SCAN_SECONDS = float(os.environ.get("BLE_SCAN_SECONDS", "12"))

def utc_now():
    return datetime.now(timezone.utc).isoformat()

async def find_device():
    if BLE_ADDRESS:
        print(f"Using configured BLE address: {BLE_ADDRESS}")
        return BLE_ADDRESS

    print(f"Scanning for BLE device named {BLE_DEVICE_NAME!r}...")
    devices = await BleakScanner.discover(timeout=SCAN_SECONDS)
    for device in devices:
        name = (device.name or "").strip()
        if name.lower() == BLE_DEVICE_NAME.lower():
            print(f"Found {name} at {device.address}")
            return device
    print("Matching BLE device not found. Nearby devices:")
    for device in devices:
        print(f"  - {device.name or '(unnamed)'} [{device.address}]")
    return None

async def main_loop():
    if not BACKEND_URL or not BRIDGE_TOKEN:
        raise SystemExit("Set BACKEND_URL and BRIDGE_TOKEN environment variables first.")
    if not BACKEND_URL.startswith(("ws://", "wss://")):
        raise SystemExit("BACKEND_URL must start with ws:// or wss:// and end with /ws.")

    while True:
        device = await find_device()
        if device is None:
            await asyncio.sleep(5)
            continue

        try:
            print("Connecting to hosted backend...")
            async with connect(BACKEND_URL, ping_interval=20, ping_timeout=20, close_timeout=5) as ws:
                await ws.send(json.dumps({"role": "bridge", "token": BRIDGE_TOKEN}))
                auth = json.loads(await asyncio.wait_for(ws.recv(), timeout=10))
                if auth.get("type") != "bridge-auth" or not auth.get("ok"):
                    raise RuntimeError("Backend rejected bridge authentication.")

                print("Backend connected. Connecting to Bluetooth robot...")
                async with BleakClient(device, timeout=15) as client:
                    if not client.is_connected:
                        raise RuntimeError("BLE connection did not complete.")

                    services = client.services
                    characteristic = None
                    for service in services:
                        for char in service.characteristics:
                            if char.uuid.lower() == CHAR_UUID.lower():
                                characteristic = char
                                break
                        if characteristic:
                            break
                    if characteristic is None:
                        raise RuntimeError(
                            f"Characteristic {CHAR_UUID} not found. Check the BLE UUID and device."
                        )

                    can_notify = "notify" in characteristic.properties or "indicate" in characteristic.properties
                    print(f"Connected to {BLE_DEVICE_NAME}; characteristic {CHAR_UUID}")
                    await ws.send(json.dumps({
                        "type": "ble-status",
                        "connected": True,
                        "message": f"Bluetooth connected to {BLE_DEVICE_NAME}."
                    }))

                    def notification_handler(sender, data):
                        payload = {
                            "type": "telemetry",
                            "data": {
                                "receivedAt": utc_now(),
                                "characteristic": str(sender),
                                "raw": bytes(data).decode("utf-8", errors="replace")
                            }
                        }
                        asyncio.create_task(ws.send(json.dumps(payload)))

                    if can_notify:
                        try:
                            await client.start_notify(characteristic, notification_handler)
                            print("Notifications enabled; raw sensor messages will be forwarded.")
                        except Exception as exc:
                            print(f"Notifications unavailable: {exc}")

                    async for raw in ws:
                        try:
                            message = json.loads(raw)
                        except json.JSONDecodeError:
                            continue
                        if message.get("type") != "command":
                            continue

                        command = message.get("command")
                        if command not in {"F", "B", "L", "R", "S", "W", "w", "M"}:
                            print(f"Ignoring unsupported command: {command!r}")
                            continue

                        try:
                            data = command.encode("ascii")
                            write_response = "write" in characteristic.properties
                            await client.write_gatt_char(
                                characteristic, data, response=write_response
                            )
                            print(f"[{utc_now()}] Sent command {command!r}")
                            await ws.send(json.dumps({
                                "type": "bridge-log",
                                "message": f"Command {command} written to Bluetooth."
                            }))
                        except Exception as exc:
                            print(f"BLE write failed: {exc}")
                            await ws.send(json.dumps({
                                "type": "ble-status",
                                "connected": False,
                                "message": f"Bluetooth command failed: {exc}"
                            }))
                            raise

                    if can_notify:
                        try:
                            await client.stop_notify(characteristic)
                        except Exception:
                            pass

        except KeyboardInterrupt:
            print("Bridge stopped by user.")
            return
        except Exception as exc:
            print(f"Bridge connection problem: {exc}")
            print("Retrying in 5 seconds. Keep this computer on and in Bluetooth range.")
            await asyncio.sleep(5)

if __name__ == "__main__":
    print(f"Farming Robot BLE bridge starting on {platform.system()}...")
    try:
        asyncio.run(main_loop())
    except KeyboardInterrupt:
        print("Bridge stopped.")
