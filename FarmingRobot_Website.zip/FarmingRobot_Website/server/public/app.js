"use strict";

const COMMANDS = { forward:"F", backward:"B", left:"L", right:"R", stop:"S", "water on":"W", "water off":"w", "moisture check":"M" };
const $ = id => document.getElementById(id);
let controlKey = sessionStorage.getItem("farmingRobotControlKey") || "";
let socket = null;
let recognition = null;
let listening = false;
let toastTimer = null;

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 3000);
}
function setDot(id, status) {
  const el = $(id);
  el.classList.toggle("online", status === true);
  el.classList.toggle("offline", status === false);
}
function log(message) {
  const box = $("activityLog");
  const empty = box.querySelector(".log-empty");
  if (empty) empty.remove();
  const row = document.createElement("p");
  const time = new Date().toLocaleTimeString();
  row.textContent = `${time} — ${message}`;
  box.prepend(row);
  while (box.children.length > 25) box.lastElementChild.remove();
}
function setStatus(data) {
  const backend = true;
  setDot("backendDot", backend);
  setDot("bridgeDot", !!data.bridgeConnected);
  setDot("bleDot", !!data.bleConnected);
  $("backendStatus").textContent = "Online";
  $("bridgeStatus").textContent = data.bridgeConnected ? "Connected" : "Offline";
  $("bleStatus").textContent = data.bleConnected ? "Connected" : "Disconnected";
  $("lastSeen").textContent = data.lastSeen ? `Updated ${new Date(data.lastSeen).toLocaleTimeString()}` : "No recent update";
  $("sysBackend").textContent = "Online";
  $("sysBridge").textContent = data.bridgeConnected ? "Connected" : "Offline";
  $("sysBle").textContent = data.bleConnected ? "Connected" : "Disconnected";
  $("sysCommand").textContent = data.lastCommand || "—";
  $("sysUpdate").textContent = data.lastSeen ? new Date(data.lastSeen).toLocaleString() : "—";
}
async function refreshStatus() {
  try {
    const response = await fetch("/api/status", { cache: "no-store" });
    if (!response.ok) throw new Error("Backend unavailable");
    setStatus(await response.json());
  } catch {
    $("backendStatus").textContent = "Unavailable";
    setDot("backendDot", false);
  }
}
async function sendCommand(command) {
  if (!controlKey) {
    $("accessDialog").showModal();
    toast("Enter your control key first.");
    return false;
  }
  try {
    const response = await fetch("/api/command", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Control-Key": controlKey },
      body: JSON.stringify({ command })
    });
    const result = await response.json();
    if (response.status === 401) {
      controlKey = "";
      sessionStorage.removeItem("farmingRobotControlKey");
      $("accessDialog").showModal();
      throw new Error("Incorrect control key. Please enter it again.");
    }
    if (!response.ok) throw new Error(result.error || "Command failed");
    log(`Command sent: ${labelFor(command)}`);
    toast(result.message || "Command sent.");
    refreshStatus();
    return true;
  } catch (error) {
    toast(error.message || "Could not send command.");
    return false;
  }
}
function labelFor(code) {
  return ({F:"Forward",B:"Backward",L:"Left",R:"Right",S:"Stop",W:"Water ON",w:"Water OFF",M:"Moisture check"})[code] || code;
}

// Tabs
document.querySelectorAll(".tab").forEach(tab => tab.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t === tab));
  document.querySelectorAll(".panel").forEach(p => p.classList.toggle("active", p.id === `panel-${tab.dataset.tab}`));
}));

// Touch controls send movement on press and Stop on release. One-shot actions are click-only.
document.querySelectorAll(".drive-btn").forEach(button => {
  const command = button.dataset.command;
  if (command === "S") {
    button.addEventListener("click", () => sendCommand("S"));
    return;
  }
  let held = false;
  const start = event => {
    if (held) return;
    held = true;
    button.classList.add("pressed");
    if (event.pointerId !== undefined && button.setPointerCapture) {
      try { button.setPointerCapture(event.pointerId); } catch {}
    }
    sendCommand(command);
  };
  const end = () => {
    if (!held) return;
    held = false;
    button.classList.remove("pressed");
    sendCommand("S");
  };
  button.addEventListener("pointerdown", start);
  button.addEventListener("pointerup", end);
  button.addEventListener("pointercancel", end);
  button.addEventListener("lostpointercapture", end);
  button.addEventListener("contextmenu", e => e.preventDefault());
});
document.querySelectorAll(".action-btn").forEach(button => button.addEventListener("click", () => sendCommand(button.dataset.command)));

// Keyboard controls. Ignore typing in inputs. Movement stops when the key is released.
const keyMap = { ArrowUp:"F", w:"F", W:"F", ArrowDown:"B", s:"B", S:"B", ArrowLeft:"L", a:"L", A:"L", ArrowRight:"R", d:"R", D:"R" };
const heldKeys = new Set();
document.addEventListener("keydown", event => {
  if (["INPUT","TEXTAREA"].includes(document.activeElement?.tagName)) return;
  if (event.repeat) return;
  const command = keyMap[event.key];
  if (command) {
    event.preventDefault();
    heldKeys.add(event.key);
    sendCommand(command);
  } else if (event.key === " " || event.key.toLowerCase() === "x") {
    event.preventDefault();
    sendCommand("S");
  }
});
document.addEventListener("keyup", event => {
  if (heldKeys.has(event.key)) {
    heldKeys.delete(event.key);
    sendCommand("S");
  }
});
window.addEventListener("blur", () => {
  if (heldKeys.size) { heldKeys.clear(); sendCommand("S"); }
});

// Access key dialog
$("accessBtn").addEventListener("click", () => {
  $("controlKey").value = "";
  $("accessDialog").showModal();
});
$("accessForm").addEventListener("submit", event => {
  event.preventDefault();
  const key = $("controlKey").value.trim();
  if (!key) return;
  controlKey = key;
  sessionStorage.setItem("farmingRobotControlKey", key);
  $("accessDialog").close();
  connectStatusSocket();
  toast("Control key saved for this tab.");
});
$("forgetKey").addEventListener("click", () => {
  controlKey = "";
  sessionStorage.removeItem("farmingRobotControlKey");
  if (socket) socket.close();
  $("accessDialog").close();
  toast("Control key forgotten.");
});

// Optional live status WebSocket; HTTP polling remains as a fallback.
function connectStatusSocket() {
  if (!controlKey) return;
  if (socket) socket.close();
  const scheme = location.protocol === "https:" ? "wss:" : "ws:";
  socket = new WebSocket(`${scheme}//${location.host}/ws`);
  socket.addEventListener("open", () => socket.send(JSON.stringify({ role:"browser", controlKey })));
  socket.addEventListener("message", event => {
    try {
      const msg = JSON.parse(event.data);
      if (msg.type === "status") setStatus(msg.data);
      if (msg.type === "telemetry") log(`Sensor message: ${JSON.stringify(msg.data)}`);
    } catch {}
  });
  socket.addEventListener("close", () => {});
}
if (controlKey) connectStatusSocket();
refreshStatus();
setInterval(refreshStatus, 4000);

// Browser speech recognition
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = "en-IN";
  recognition.onstart = () => {
    listening = true;
    $("voiceState").textContent = "Listening…";
    $("startVoice").disabled = true;
    $("stopVoice").disabled = false;
  };
  recognition.onend = () => {
    if (listening) {
      try { recognition.start(); } catch {}
    } else {
      $("voiceState").textContent = "Voice control is off";
      $("startVoice").disabled = false;
      $("stopVoice").disabled = true;
    }
  };
  recognition.onerror = event => {
    $("voiceState").textContent = `Microphone: ${event.error}`;
    if (event.error === "not-allowed" || event.error === "service-not-allowed") {
      listening = false;
      try { recognition.stop(); } catch {}
    }
  };
  recognition.onresult = event => {
    let finalText = "";
    let interimText = "";
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const text = event.results[i][0].transcript.toLowerCase().trim();
      if (event.results[i].isFinal) finalText += " " + text;
      else interimText += " " + text;
    }
    $("heardText").textContent = (finalText || interimText || "Listening…").trim();
    if (!finalText) return;
    const phrase = finalText.toLowerCase();
    const aliases = [
      [["water off","stop water","pump off"], "w"],
      [["water on","start water","pump on"], "W"],
      [["moisture check","check moisture","check soil","soil moisture"], "M"],
      [["backward","reverse","go back"], "B"],
      [["forward","go ahead","move ahead"], "F"],
      [["left"], "L"], [["right"], "R"], [["stop","halt"], "S"]
    ];
    for (const [phrases, command] of aliases) {
      if (phrases.some(p => phrase.includes(p))) {
        sendCommand(command);
        $("voiceState").textContent = `Command: ${labelFor(command)}`;
        return;
      }
    }
  };
} else {
  $("voiceState").textContent = "Voice recognition is not supported by this browser.";
  $("startVoice").disabled = true;
  $("heardText").textContent = "Try a supported browser such as Chrome. Availability varies by device.";
}
$("startVoice").addEventListener("click", () => {
  if (!recognition) return;
  listening = true;
  try { recognition.start(); } catch { toast("Voice recognition could not start. Check microphone permission."); }
});
$("stopVoice").addEventListener("click", () => {
  listening = false;
  if (recognition) recognition.stop();
});
$("clearLog").addEventListener("click", () => {
  $("activityLog").innerHTML = '<p class="log-empty">No commands sent in this session.</p>';
});

// If a tab is hidden or the page closes, stop movement defensively.
window.addEventListener("pagehide", () => {
  if (heldKeys.size) {
    heldKeys.clear();
    // A beacon cannot attach the control header, so no command is sent here.
  }
});
