"use strict";

const http = require("http");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { URL } = require("url");
const WebSocket = require("ws");

const PORT = Number(process.env.PORT || 3000);
const BRIDGE_TOKEN = process.env.BRIDGE_TOKEN || "";
const WEB_CONTROL_KEY = process.env.WEB_CONTROL_KEY || "";
const PUBLIC_DIR = path.join(__dirname, "public");

const state = {
  bridgeConnected: false,
  bleConnected: false,
  lastSeen: null,
  lastCommand: null,
  lastCommandAt: null,
  message: "Waiting for the Bluetooth bridge to connect."
};

let bridgeSocket = null;
const browserSockets = new Set();

function safeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || !a || !b) return false;
  const aa = Buffer.from(a);
  const bb = Buffer.from(b);
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

function sendJson(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, X-Control-Key",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  });
  res.end(JSON.stringify(data));
}

function publicState() {
  return { ...state, bridgeConnected: Boolean(bridgeSocket && bridgeSocket.readyState === WebSocket.OPEN) };
}

function broadcast() {
  const message = JSON.stringify({ type: "status", data: publicState() });
  for (const socket of browserSockets) {
    if (socket.readyState === WebSocket.OPEN && socket.authenticated) socket.send(message);
  }
}

function serveStatic(req, res) {
  let pathname = decodeURIComponent(new URL(req.url, `http://${req.headers.host || "localhost"}`).pathname);
  if (pathname === "/") pathname = "/index.html";
  const target = path.resolve(PUBLIC_DIR, "." + pathname);
  if (!target.startsWith(PUBLIC_DIR + path.sep) && target !== path.join(PUBLIC_DIR, "index.html")) {
    res.writeHead(403); return res.end("Forbidden");
  }
  fs.readFile(target, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const ext = path.extname(target).toLowerCase();
    const types = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml" };
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream", "Cache-Control": "no-cache" });
    res.end(data);
  });
}

const server = http.createServer((req, res) => {
  if (req.method === "OPTIONS") return sendJson(res, 204, {});
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  if (url.pathname === "/api/status" && req.method === "GET") {
    return sendJson(res, 200, publicState());
  }

  if (url.pathname === "/api/command" && req.method === "POST") {
    if (!WEB_CONTROL_KEY) return sendJson(res, 503, { ok: false, error: "WEB_CONTROL_KEY is not configured on the backend." });
    if (!safeEqual(req.headers["x-control-key"], WEB_CONTROL_KEY)) return sendJson(res, 401, { ok: false, error: "Control key is incorrect." });

    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 4096) req.destroy();
    });
    req.on("end", () => {
      let payload;
      try { payload = JSON.parse(body || "{}"); } catch { return sendJson(res, 400, { ok: false, error: "Invalid JSON." }); }
      const allowed = new Set(["F", "B", "L", "R", "S", "W", "w", "M"]);
      if (!allowed.has(payload.command)) return sendJson(res, 400, { ok: false, error: "Unsupported command." });
      if (!bridgeSocket || bridgeSocket.readyState !== WebSocket.OPEN) {
        return sendJson(res, 503, { ok: false, error: "Bluetooth bridge is offline. Start bridge.py on the nearby computer." });
      }
      bridgeSocket.send(JSON.stringify({ type: "command", command: payload.command }));
      state.lastCommand = payload.command;
      state.lastCommandAt = new Date().toISOString();
      state.message = `Command ${payload.command} sent to bridge.`;
      broadcast();
      return sendJson(res, 200, { ok: true, message: state.message });
    });
    return;
  }

  serveStatic(req, res);
});

const wss = new WebSocket.Server({ noServer: true });
server.on("upgrade", (req, socket, head) => {
  const pathname = new URL(req.url, `http://${req.headers.host || "localhost"}`).pathname;
  if (pathname !== "/ws") { socket.destroy(); return; }
  wss.handleUpgrade(req, socket, head, ws => wss.emit("connection", ws, req));
});

wss.on("connection", ws => {
  ws.authenticated = false;
  ws.role = null;
  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { ws.close(1003, "JSON required"); return; }

    if (!ws.authenticated) {
      if (msg.role === "bridge" && BRIDGE_TOKEN && safeEqual(msg.token, BRIDGE_TOKEN)) {
        if (bridgeSocket && bridgeSocket !== ws && bridgeSocket.readyState === WebSocket.OPEN) bridgeSocket.close(4001, "Replaced by a new bridge");
        bridgeSocket = ws;
        ws.authenticated = true;
        ws.role = "bridge";
        state.bridgeConnected = true;
        state.lastSeen = new Date().toISOString();
        state.message = "Bridge connected; waiting for BLE status.";
        ws.send(JSON.stringify({ type: "bridge-auth", ok: true }));
        broadcast();
        return;
      }
      if (msg.role === "browser" && WEB_CONTROL_KEY && safeEqual(msg.controlKey, WEB_CONTROL_KEY)) {
        ws.authenticated = true;
        ws.role = "browser";
        browserSockets.add(ws);
        ws.send(JSON.stringify({ type: "status", data: publicState() }));
        return;
      }
      ws.close(4003, "Authentication failed");
      return;
    }

    if (ws.role === "bridge") {
      if (msg.type === "ble-status") {
        state.bleConnected = Boolean(msg.connected);
        state.lastSeen = new Date().toISOString();
        state.message = msg.message || (state.bleConnected ? "Bluetooth connected." : "Bluetooth disconnected.");
        broadcast();
      } else if (msg.type === "bridge-log") {
        state.lastSeen = new Date().toISOString();
        state.message = String(msg.message || "Bridge update").slice(0, 300);
        broadcast();
      } else if (msg.type === "telemetry") {
        // Forward optional sensor messages without assuming their format.
        for (const client of browserSockets) {
          if (client.readyState === WebSocket.OPEN && client.authenticated) client.send(JSON.stringify({ type: "telemetry", data: msg.data }));
        }
      }
    }
  });

  ws.on("close", () => {
    browserSockets.delete(ws);
    if (bridgeSocket === ws) {
      bridgeSocket = null;
      state.bridgeConnected = false;
      state.bleConnected = false;
      state.message = "Bluetooth bridge disconnected.";
      broadcast();
    }
  });
  ws.on("error", () => {});
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Farming Robot server listening on port ${PORT}`);
  if (!BRIDGE_TOKEN || !WEB_CONTROL_KEY) {
    console.warn("Set BRIDGE_TOKEN and WEB_CONTROL_KEY environment variables before using remote control.");
  }
});
